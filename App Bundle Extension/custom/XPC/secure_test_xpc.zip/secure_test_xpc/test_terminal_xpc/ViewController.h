#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (weak) IBOutlet NSTextView *textView;  // For displaying content
- (IBAction)readAndWriteAction:(id)sender;       // For button action
@end
