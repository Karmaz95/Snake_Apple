#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
}

- (NSString*)readFromFile {
    NSString *path = [@"~/Desktop/xpc_test_read" stringByExpandingTildeInPath];
    NSError *error = nil;
    
    NSString *content = [NSString stringWithContentsOfFile:path
                                                encoding:NSUTF8StringEncoding
                                                   error:&error];
    
    if (error) {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert setMessageText:@"Error Reading File"];
        [alert setInformativeText:[error localizedDescription]];
        [alert runModal];
        return nil;
    }
    
    return content;
}

- (void)writeToFile:(NSString *)content {
    NSString *path = [@"~/Desktop/xpc_test_write" stringByExpandingTildeInPath];
    NSError *error = nil;
    
    [content writeToFile:path
              atomically:YES
                encoding:NSUTF8StringEncoding
                   error:&error];
    
    if (error) {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert setMessageText:@"Error Writing File"];
        [alert setInformativeText:[error localizedDescription]];
        [alert runModal];
    }
}

- (IBAction)readAndWriteFile:(id)sender {
    NSString *content = [self readFromFile];
    if (content) {
        [self.textView setString:content];
        [self writeToFile:content];
    }
}

@end
