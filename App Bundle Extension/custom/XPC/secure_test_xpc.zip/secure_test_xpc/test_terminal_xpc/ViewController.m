#import "ViewController.h"
#import "test_terminal_xpc_helperProtocol.h" // Use the protocol we made in XPC helper

@interface ViewController ()
@property (strong) NSXPCConnection *xpcConnection;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"App: viewDidLoad called");
    [self setupXPCConnection];
}

- (void)setupXPCConnection {
    NSLog(@"App: setting up XPC connection");
    self.xpcConnection = [[NSXPCConnection alloc] initWithServiceName:@"crimson.test-terminal-xpc-helper"];
    self.xpcConnection.remoteObjectInterface = [NSXPCInterface interfaceWithProtocol:@protocol(test_terminal_xpc_helperProtocol)];
    [self.xpcConnection resume];
}
- (void)writeToFile:(NSString *)content {
    NSString *homeDirectory = NSHomeDirectory();
    NSString *path = [homeDirectory stringByAppendingPathComponent:@"Downloads/xpc_test_write"];
    NSError *error = nil;
    
    [content writeToFile:path
              atomically:YES
                encoding:NSUTF8StringEncoding
                   error:&error];
    
    if (error) {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert setMessageText:@"Error Writing File"];
        [alert setInformativeText:[error localizedDescription]];
        [alert runModal];
    }
}

- (IBAction)readAndWriteAction:(id)sender {
    id<test_terminal_xpc_helperProtocol> proxy = [self.xpcConnection remoteObjectProxy];
    
    [proxy readFileWithCompletion:^(NSString *content, NSError *error) {
        if (error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                NSAlert *alert = [[NSAlert alloc] init];
                [alert setMessageText:@"Error Reading File"];
                [alert setInformativeText:[error localizedDescription]];
                [alert runModal];
            });
            return;
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.textView setString:content];
            [self writeToFile:content];
        });
    }];
}

@end
