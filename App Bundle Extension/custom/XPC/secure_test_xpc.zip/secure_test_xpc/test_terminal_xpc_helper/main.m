#import <Foundation/Foundation.h>
#import "test_terminal_xpc_helper.h"

// 1. Bundle ID (Identifier): Prevents other apps from the same developer from accessing the service.
#define CLIENT_BUNDLE_ID  @"crimson.test-terminal-xpc"

// 2. Team ID (TeamIdentifier): Only binaries from the authorized organization can connect.
#define CLIENT_TEAM_ID    @"CW5M93XVT3"

// 3. Minimum Version (CFBundleShortVersionString): Blocks outdated clients with known vulnerabilities
#define CLIENT_MIN_VER    @"1.0"

@interface ServiceDelegate : NSObject <NSXPCListenerDelegate>
@end

@implementation ServiceDelegate

- (BOOL)listener:(NSXPCListener *)listener shouldAcceptNewConnection:(NSXPCConnection *)newConnection {
    
    // Requirement Explanation:
    // 1. anchor apple generic  -> Signed by Apple (Apple Root CA)
    // 2. identifier            -> Matches the expected Bundle ID
    // 3. subject.OU            -> Matches your specific Team ID (Organization)
    // 4. info[...]             -> Matches or exceeds minimum version
    NSString *requirementString = [NSString stringWithFormat:
        @"anchor apple generic and "
        @"identifier \"%@\" and "
        @"certificate leaf[subject.OU] = \"%@\" and "
        @"info[CFBundleShortVersionString] >= \"%@\"",
        CLIENT_BUNDLE_ID, CLIENT_TEAM_ID, CLIENT_MIN_VER];

    // Create the code signing requirement
    [newConnection setCodeSigningRequirement:requirementString];

    // Standard XPC setup
    newConnection.exportedInterface = [NSXPCInterface interfaceWithProtocol:@protocol(test_terminal_xpc_helperProtocol)];
    test_terminal_xpc_helper *exportedObject = [test_terminal_xpc_helper new];
    newConnection.exportedObject = exportedObject;

    [newConnection resume];
    
    return YES;
}

int main(int argc, const char *argv[])
{
    // Create the delegate for the service.
    ServiceDelegate *delegate = [ServiceDelegate new];
    
    // Set up the one NSXPCListener for this service. It will handle all incoming connections.
    NSXPCListener *listener = [NSXPCListener serviceListener];
    listener.delegate = delegate;
    
    // Resuming the serviceListener starts this service. This method does not return.
    [listener resume];
    return 0;
}

@end
