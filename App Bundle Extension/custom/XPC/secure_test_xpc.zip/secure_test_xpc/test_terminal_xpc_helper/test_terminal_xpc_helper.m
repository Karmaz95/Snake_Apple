#import "test_terminal_xpc_helper.h"

@implementation test_terminal_xpc_helper

- (void)readFileWithCompletion:(void (^)(NSString *content, NSError *error))completion {
    NSLog(@"XPC helper: attempting to read file");
    
    // Resolve the full path to the file
    NSString *homeDirectory = NSHomeDirectory();
    NSString *path = [homeDirectory stringByAppendingPathComponent:@"Desktop/xpc_test_read"];
    NSLog(@"XPC helper: reading from path: %@", path);
    
    // Read the file content
    NSError *error = nil;
    NSString *content = [NSString stringWithContentsOfFile:path
                                                  encoding:NSUTF8StringEncoding
                                                     error:&error];
    if (error) {
        NSLog(@"XPC helper: error reading file: %@", error);
    }
    
    // Return the content or error to the caller
    completion(content, error);
}

@end
