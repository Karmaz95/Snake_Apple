#import <Foundation/Foundation.h>

// This protocol is used by the helper to communicate with the main app
@protocol test_terminal_xpc_helperProtocol

- (void)readFileWithCompletion:(void (^)(NSString *content, NSError *error))completion;

@end
