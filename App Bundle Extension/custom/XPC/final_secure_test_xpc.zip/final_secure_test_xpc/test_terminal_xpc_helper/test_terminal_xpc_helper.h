#import <Foundation/Foundation.h>
#import "test_terminal_xpc_helperProtocol.h"

// This object implements the protocol which we have defined. It provides the actual behavior for the service.
@interface test_terminal_xpc_helper : NSObject <test_terminal_xpc_helperProtocol>
@end
