#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
@property (strong) IBOutlet NSWindow *window;
@property (strong) IBOutlet NSTextView *textView;

- (IBAction)readAndWriteFile:(id)sender;
@end
